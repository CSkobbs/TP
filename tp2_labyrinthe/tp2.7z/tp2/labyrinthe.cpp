#include "labyrinthe.h"
#include <list>

// Construit un labyrinthe sur la base du nom de fichier
// appelle directement le constructeur de la classe m�re
Labyrinthe::Labyrinthe(const std::string& nom_fichier) :
    Labybase(nom_fichier)
{   }

// Exemple de parcours de tous les sommets du graphe dans l'ordre de leur indice
void Labyrinthe::affichage_donnees()
{
    std::cout << std::endl;

    std::cout << "Le labyrinthe a " << m_ordre << " sommets" << std::endl;

    std::cout << "Le sommet entree est a l'indice " << m_entree
                  << " coords" << coords(m_entree) << std::endl;

    std::cout << "Le sommet sortie est a l'indice " << m_sortie
                  << " coords" << coords(m_sortie) << std::endl;

    std::cout << std::endl << "Liste de tous les sommets : " << std::endl;
    for (int idx=0; idx<m_ordre; ++idx)
    {
        Sommet& s = m_sommets[idx];

        std::cout << "sommet indice " << idx << " coords" << coords(idx)
                    << (s.m_marque ? " X" : "  ") << (s.m_carac ? s.m_carac : ' ') << " adjacents: ";

        /// POUR REALISER LES ALGORITHMES DE PARCOURS VOUS DEVEZ BIEN COMPRENDRE CES 3 LIGNES
        for (int a=0; a<s.m_nbadjacents; ++a)
        {
            int ida = s.m_adjacents[a];
            std::cout << ida << " ";
        }

        if (s.m_nbadjacents==0)
            std::cout << "Aucun";

        std::cout << std::endl;
    }
    std::cout << std::endl;

    /**
    // La m�me chose avec des accesseurs et une boucle for in (selon votre pr�f�rence)
    std::cout << std::endl << "Liste de tous les sommets : " << std::endl;
    for (int idx=0; idx<get_ordre(); ++idx)
    {
        Sommet& s = get_sommet(idx);

        std::cout << "sommet indice " << idx << " coords" << coords(idx)
                    << (s.est_marque() ? " X" : "  ") << (s.get_carac() ? s.get_carac() : ' ') << " adjacents: ";

        for ( auto ida : s.get_adjacents() )
            std::cout << ida << " ";

        if ( s.get_adjacents().size()==0 )
            std::cout << "Aucun";

        std::cout << std::endl;
    }
    std::cout << std::endl;
    */

}


/// ICI VOS METHODES ...

void Labyrinthe::composantes_connexes() /// m�thode affichage composantes connexes
{
    reset_marquages(); /// on r�initialise les marquages pour ne pas causer d'erreur dans la fonction

    char caractere = '1';   /// caract�re actif repr�sentant le groupe de composantes connexes ( le premier par des 1 )

    for (int i= 0; i< m_ordre; i++) /// on parcourt tout les sommets
    {
        if (m_sommets[i].get_carac() == '\0')   /// si le caract�re est vide,....
        {
            DFS(i, true);                             /// alors on fait un DFS pour trouver tout les composants appartenant au groupe et les marquer
            for (int j = 0; j< m_ordre; j++)    /// on reparcourt tout les sommets
            {
                if (m_sommets[j].est_marque())  /// s'il est marqu�...
                    m_sommets[j].set_carac(caractere);  /// alors on lui attribue le caract�re du groupe actif.
            }
            caractere += 1;                     /// on change le caract�re actif, afin que le prochain grouoe soit repr�sent� diff�remment.
            reset_marquages();                  /// et on r�initialise les marquages pour que l'on ne change pas les groupes faits.
        }
    }


}

void Labyrinthe::DFS(int entree , bool CC )    /// parcours en profondeur ( on prend en param�tre le sommet actif, et si l'appel est fait par la fonction composantes connexes ) ( fonstion r�cursive )
{
    if (!CC)
        std::cout << entree << " " ; /// on affiche l'indice du sommet actuel quand on fait le DFS

    m_sommets[entree].set_marque(true); /// on marque le sommet actuel

    for (int i = 0; i< m_sommets[entree].get_adjacents().size() ; i++)  /// on fait l'op�ration pour tout les sommet adjacents
    {
        if ((m_sommets[entree].get_adjacents()[i] == m_sortie)&&(!m_sommets[m_sommets[entree].get_adjacents()[i]].est_marque())&&(!CC)) /// on teste si on est sur la sortie
        {
            m_sommets[m_sommets[entree].get_adjacents()[i]].set_marque(true);   /// on marque le sommet comme visit�

            std::cout << std::endl << std::endl << std::endl << "chemin parcouru :" << std::endl << std::endl;
            afficher();                                                                                              /// on affiche le chemin parcouru
            std::cout << std::endl << std::endl << std::endl << "suite du parcours : " << std::endl << std::endl;
        }

        if (!m_sommets[m_sommets[entree].get_adjacents()[i]].est_marque())
            DFS(m_sommets[entree].get_adjacents()[i], CC);                  /// on rapelle le programme afin de continuer l'exploration en profondeur
    }
}

void Labyrinthe::BFS(int entree)
{
    reset_marquages(); /// on r�initialise pour �viter les erreurs

    std::list<int> file;    /// file de stockage des sommets

    m_sommets[entree].set_marque(true); /// on marque l'entr�e comme visit�e
    file.push_back(entree);             /// on rajoute l'indice de l'entr�e � la liste de stockage

    while(!file.empty())        /// tant qu'il y a des sommets � explorer...
    {
        entree = file.front();  /// on r�cup�re l'indice le plus en avant
        std::cout << entree << " "; /// on l'affiche
        file.pop_front();       /// et on le supprime de la liste " a explorer "

        for ( int i = 0 ; i < m_sommets[entree].get_adjacents().size() ; i++) /// on explore tout ses voisins
        {
            if (!m_sommets[m_sommets[entree].get_adjacents()[i]].est_marque())
            {
                if ((m_sommets[entree].get_adjacents()[i] == m_sortie)&&(!m_sommets[m_sommets[entree].get_adjacents()[i]].est_marque())) /// si c'est la sortie
                {
                    std::cout << std::endl << std::endl << std::endl << "chemin parcouru :" << std::endl << std::endl;
                    afficher();                                                                                         /// on montre le chemin effectu�
                    std::cout << std::endl << std::endl << std::endl << "suite du parcours : " << std::endl << std::endl;
                }
                m_sommets[m_sommets[entree].get_adjacents()[i]].set_marque(true); ///on le marque visit�
                file.push_back(m_sommets[entree].get_adjacents()[i]);   /// on ajoute les sommets voisins � la liste.
            }
        }
    }
}

/// Ce code � �t� tr�s fortemment inspir� du site internet geeksforgeeks.com , envoy� par Mr.Segado.
/// C'est grace � lui que j'ai pu comprendre la programmation de ces parcours, et r�aliser ces trois m�thodes.



